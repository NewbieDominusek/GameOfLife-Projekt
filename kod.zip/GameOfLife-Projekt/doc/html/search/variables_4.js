var searchData=
[
  ['family_0',['family',['../structsf_1_1Font_1_1Info.html#a008413b4b6cf621eb92668a11098a519',1,'sf::Font::Info']]],
  ['finger_1',['finger',['../structsf_1_1Event_1_1TouchEvent.html#a9a79fe86bf9ac3c16ec7326f96feb61a',1,'sf::Event::TouchEvent']]]
];
